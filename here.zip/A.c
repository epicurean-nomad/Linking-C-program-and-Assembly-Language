#include <stdlib.h>
#include <stdio.h>


void A(){
    printf("In function A:\n");
    unsigned long long k;
    scanf("%llu",&k);
    extern void B(unsigned long long k);
    B(k);
}
int main()
{
    A();
    return 0;
}
