#include <stdlib.h>
#include <stdio.h>


void C(){
    printf("\nIn function C\n");
    exit(0);
}